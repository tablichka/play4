package jds.l2.gameserver.dataholders;

import javolution.util.FastList;
import javolution.util.FastMap;
import jds.l2.gameserver.model.locations.SpawnLocation;
import jds.l2.global.dataholders.AbstractHolder;

/**
 * Author: VISTALL
 * Company: J Develop Station
 * Date: 03/01/2010
 * Time: 22:08:46
 */
public final class HellboundHolder extends AbstractHolder
{
	private static HellboundHolder _instance;
	// hbLevel[npcId[spawnlocation]]
	private FastMap<Byte, FastMap<Integer, FastList<SpawnLocation>>> _hbList = new FastMap<Byte, FastMap<Integer, FastList<SpawnLocation>>>();
	private int _size;

	public static HellboundHolder getInstance()
	{
		if (_instance == null)
		{
			_instance = new HellboundHolder();
		}
		return _instance;
	}

	private HellboundHolder()
	{

	}

	public void addSpawn(byte level, int npcId, SpawnLocation loc)
	{
		if(!_hbList.containsKey(level))
		{
			_hbList.put(level, new FastMap<Integer, FastList<SpawnLocation>>());
		}

		FastMap<Integer, FastList<SpawnLocation>> npcSpawn = _hbList.get(level);

		if(!npcSpawn.containsKey(npcId))
		{
			npcSpawn.put(npcId, new FastList<SpawnLocation>());
		}

		FastList<SpawnLocation> list =  npcSpawn.get(npcId);

		list.add(loc);

		_size ++;
	}

	@Override
	public void log()
	{
		info("load " + _size + " spawns.");
	}

	@Deprecated
	@Override
	public int size()
	{
		return 0;
	}

	@Override
	public void clear()
	{
	 	_hbList.clear();
	}

	public FastMap<Integer, FastList<SpawnLocation>> getSpawnList(byte level)
	{
		return _hbList.get(level);
	}
}