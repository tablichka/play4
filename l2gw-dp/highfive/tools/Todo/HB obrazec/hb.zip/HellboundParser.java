package jds.l2.gameserver.parsers;

import jds.l2.gameserver.dataholders.HellboundHolder;
import jds.l2.gameserver.model.locations.SpawnLocation;
import jds.l2.global.xml.AbstractFileParser;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

/**
 * Author: VISTALL
 * Company: J Develop Station
 * Date: 03/01/2010
 * Time: 22:08:31
 */
public final class HellboundParser extends AbstractFileParser
{
	private static HellboundParser _instance;

	public static HellboundParser getInstance()
	{
		if (_instance == null)
		{
			_instance = new HellboundParser();
		}
		return _instance;
	}

	public HellboundParser()
	{
		super("./data/hellbound.xml");
		_holder = HellboundHolder.getInstance();
		super.parse();
	}

	@Override
	protected void readData(Node start0)
	{
		if ("list".equalsIgnoreCase(start0.getNodeName()))
		{
			for (Node n = start0.getFirstChild(); n != null; n = n.getNextSibling())
			{
				if ("hellbound".equalsIgnoreCase(n.getNodeName()))
				{
					NamedNodeMap map = n.getAttributes();
					byte level = byteValue(map.getNamedItem("level"));

					for (Node s1 = n.getFirstChild(); s1 != null; s1 = s1.getNextSibling())
					{
						if ("npc".equalsIgnoreCase(s1.getNodeName()))
						{
							map = s1.getAttributes();
							int npcId = intValue(map.getNamedItem("id"));

							for (Node s2 = s1.getFirstChild(); s2 != null; s2 = s2.getNextSibling())
							{
								if ("spawnlist".equalsIgnoreCase(s2.getNodeName()))
								{
									for (Node s3 = s2.getFirstChild(); s3 != null; s3 = s3.getNextSibling())
									{
										if ("spawn".equalsIgnoreCase(s3.getNodeName()))
										{
											NamedNodeMap nS2 = s3.getAttributes();
											SpawnLocation loc;

											if (nS2.getNamedItem("territoryId") == null)
											{
												int x = intValue(nS2.getNamedItem("x"));
												int y = intValue(nS2.getNamedItem("y"));
												int z = intValue(nS2.getNamedItem("z"));
												int h = intValue(nS2.getNamedItem("h"));
												loc = new SpawnLocation(x, y, z, h);
											}
											else
											{
												int territoryId = intValue(nS2.getNamedItem("territoryId"));
												loc = new SpawnLocation(territoryId);
											}

											int count = nS2.getNamedItem("count") != null ? intValue(nS2.getNamedItem("count")) : 1;
											int respawn_delay = nS2.getNamedItem("respawn_delay") != null ? intValue(nS2.getNamedItem("respawn_delay")) : 60;
											int respawn_delay_rnd = nS2.getNamedItem("respawn_delay_rnd") != null ? intValue(nS2.getNamedItem("respawn_delay_rnd")) : 0;
											int periodOfDay = nS2.getNamedItem("periodOfDay") != null ? intValue(nS2.getNamedItem("periodOfDay")) : 0;
											String ai = nS2.getNamedItem("ai") != null ? nS2.getNamedItem("ai").getNodeValue() : null;

											loc.setCount(count);
											loc.setRespawnDelay(respawn_delay);
											loc.setRespawnDelayRnd(respawn_delay_rnd);
											loc.setPeriodOfDay(periodOfDay);
											loc.setAi(ai);

											if(DEBUG)
											{
												_log.info(String.format("Adding spawn for level %d npcID %d", level, npcId));
											}
											getHolder().addSpawn(level, npcId, loc);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	@Override
	public HellboundHolder getHolder()
	{
		return (HellboundHolder) _holder;
	}
}
