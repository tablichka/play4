package jds.l2.global.dataholders;

import jds.l2.global.util.StringUtil;
import org.apache.log4j.Logger;

/**
 * Author: VISTALL
 * Date: 20.07.2009
 * Time: 12:27:04
 */
public abstract class AbstractHolder
{
	protected Logger _log = Logger.getLogger(getClass().getSimpleName());

	public void log()
	{
		_log.info(String.format("[%s] load %d %s(s) count.", getClass().getSimpleName(), size(), StringUtil.unknown(getClass().getSimpleName().replace("Holder", "")).toLowerCase()));
	}

	public void info(String s)
	{
		_log.info(String.format("[%s] %s", getClass().getSimpleName(), s));
	}

	public abstract int size();

	public abstract void clear();
}